package com.example.slotbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.random.Random

class SlotService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var busy = false

    private val tick = object : Runnable {
        override fun run() {
            try { step() } catch (_: Exception) { busy = false }
            h.postDelayed(this, Random.nextLong(4000, 9000))
        }
    }

    override fun onServiceConnected() { h.post(tick) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)
    private fun list(s: String?) = (s ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private fun slotRegex(slot: String): Regex {
        val parts = slot.split(Regex("\\s*[-–]\\s*"))
        if (parts.size != 2) return Regex(Regex.escape(slot))
        return Regex(".*${Regex.escape(parts[0])}\\s*[-–]\\s*${Regex.escape(parts[1])}.*", RegexOption.DOT_MATCHES_ALL)
    }

    private fun find(n: AccessibilityNodeInfo?, ok: (String) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        val t = (n.text ?: n.contentDescription)?.toString()
        if (t != null && ok(t)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), ok)?.let { return it }
        return null
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableSet<String>) {
        if (n == null) return
        (n.text ?: n.contentDescription)?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    private fun click(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        (n ?: node).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun swipeRefresh() {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.35f)
            lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.75f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }

    private fun step() {
        if (busy) return
        val p = prefs()
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return

        if (p.getBoolean("dump", false)) {
            val set = linkedSetOf<String>()
            collect(root, set)
            p.edit().putString("dump_out", "Paket: $pkg\n\n" + set.joinToString("\n"))
                .putBoolean("dump", false).apply()
            return
        }

        if (!p.getBoolean("enabled", false)) return
        val want = p.getString("pkg", "")!!.trim()
        if (want.isNotEmpty() && pkg != want) return

        val done = list(p.getString("done", "")).toSet()
        val remaining = list(p.getString("slots", "")).filter { it !in done }
        if (remaining.isEmpty()) { p.edit().putBoolean("enabled", false).apply(); return }

        for (slot in remaining) {
            val rx = slotRegex(slot)
            val node = find(root) { rx.matches(it) } ?: continue
            book(node, slot)
            return
        }
        swipeRefresh()
    }

    private fun book(node: AccessibilityNodeInfo, slot: String) {
        busy = true
        click(node)
        h.postDelayed({
            val confirms = list(prefs().getString("confirm", ""))
            repeat(2) { round ->
                h.postDelayed({
                    val r = rootInActiveWindow ?: return@postDelayed
                    for (c in confirms) {
                        val b = find(r) { it.equals(c, ignoreCase = true) }
                        if (b != null) { click(b); break }
                    }
                }, round * 1000L)
            }
            h.postDelayed({ verify(slot) }, 2600)
        }, 1000)
    }

    private fun verify(slot: String) {
        val p = prefs()
        val r = rootInActiveWindow
        val successes = list(p.getString("success", ""))
        val ok = r != null && successes.any { s ->
            find(r) { it.contains(s, ignoreCase = true) } != null
        }
        if (ok) {
            val done = list(p.getString("done", "")) + slot
            p.edit().putString("done", done.joinToString(",")).apply()
            try { RingtoneManager.getRingtone(this,
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play() } catch (_: Exception) {}
        } else {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        busy = false
    }
}
