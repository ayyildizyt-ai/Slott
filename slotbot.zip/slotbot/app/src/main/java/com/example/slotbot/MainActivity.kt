package com.example.slotbot

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var p: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        p = getSharedPreferences("cfg", MODE_PRIVATE)

        val slots = findViewById<EditText>(R.id.slots)
        val confirm = findViewById<EditText>(R.id.confirm)
        val success = findViewById<EditText>(R.id.success)
        val pkg = findViewById<EditText>(R.id.pkg)

        slots.setText(p.getString("slots", "18:00-20:00,20:00-22:00"))
        confirm.setText(p.getString("confirm", "Rezerve Et,Onayla,Al,Evet"))
        success.setText(p.getString("success", "Rezerve edildi,Başarılı,Vardiya alındı"))
        pkg.setText(p.getString("pkg", ""))

        fun save() = p.edit()
            .putString("slots", slots.text.toString())
            .putString("confirm", confirm.text.toString())
            .putString("success", success.text.toString())
            .putString("pkg", pkg.text.toString())
            .apply()

        findViewById<Button>(R.id.access).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.start).setOnClickListener {
            save()
            p.edit().putString("done", "").putBoolean("enabled", true).apply()
            Toast.makeText(this, "Başladı. Kurye uygulamasını slot ekranında aç.", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            p.edit().putBoolean("enabled", false).apply()
            Toast.makeText(this, "Durdu", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.dump).setOnClickListener {
            p.edit().putBoolean("dump", true).apply()
            Toast.makeText(this, "Şimdi kurye uygulamasına geç, sonra buraya dön.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.dumpOut).text = p.getString("dump_out", "")
    }
}
